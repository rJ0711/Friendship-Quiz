package com.rocks.enemytest;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.rocks.enemytest";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final int VERSION_CODE = 33;
  public static final String VERSION_NAME = "0.33";
}


/* Location:           P:\dex2jar-0.0.9.15\classes_dex2jar.jar
 * Qualified Name:     com.rocks.enemytest.BuildConfig
 * JD-Core Version:    0.7.0.1
 */